﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ticketing.Data;
using Ticketing.Models;
using Ticketing.Controllers;
using System.Net.Sockets;
using Ticketing.Migrations;


namespace Ticketing.Controllers
{
    public class TicketsController : Controller
    {
        private readonly TicketingContext _context;

        public TicketsController(TicketingContext context)
        {
            _context = context;
        }

        // GET: Tickets
        public async Task<IActionResult> Index(string status, string searchString)
        {
            if (_context.Ticket == null || _context.Status == null || _context.Mitarbeiters == null)
            {
                return Problem("Entity set 'TicketingContext.Tickets' or 'TicketingContext.Status' or 'TicketingContext.Mitarbeiters' is null.");
            }

    

            IQueryable<string> statusQuery = from t in _context.Ticket
                                             join s in _context.Status on t.StatusId equals s.Id
                                             join m in _context.Mitarbeiters on t.MitarbeiterId equals m.Id
                                             orderby s.Name
                                             select s.Name;


            var tickets = _context.Ticket
                    .Include(t => t.Status)
                    .Include(t => t.Mitarbeiter)

                    .AsQueryable();



          
            if (!String.IsNullOrEmpty(searchString))
            {
                tickets = tickets.Where(t => t.Betreff!.ToUpper().Contains(searchString.ToUpper()));
            }


            if (!string.IsNullOrEmpty(status))
            {
                tickets = tickets.Where(x => x.Status.Name == status);
            }

            var viewModel = new TicketStatusViewModel
            {
                Status = new SelectList(await statusQuery.Distinct().ToListAsync()),  
                Tickets = await tickets.ToListAsync(), 
                Name = status,
                SearchString = searchString
            };


            return View(viewModel);
        }




        [HttpPost]
        public string Index(string searchString, bool notUsed)
        {
            return "From [HttpPost]Index: filter on " + searchString;
        }



        // GET: Tickets/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ticket = await _context.Ticket
                .FirstOrDefaultAsync(t => t.Id == id);

            if (ticket == null)
            {
                return NotFound();
            }


            // get ticket by ID
            var tickets = await _context.Ticket
            .Include(t => t.Status)
            .FirstOrDefaultAsync(t => t.Id == id);

            // get status list
            IQueryable<string> statusQuery = from t in _context.Ticket
                                             join s in _context.Status on t.StatusId equals s.Id
                                             orderby s.Name
                                             select s.Name;

            var viewModel = new TicketDetailsViewModel
            {
                Ticket = ticket,
                Status = ticket.Status,
            };


            return View(viewModel);
        }

        // GET: Tickets/Create
        public async Task<IActionResult> Create()
        {

            IQueryable<string> statusQuery = from s in _context.Status
                                             orderby s.Name
                                             select s.Name;

            /*IQueryable<dynamic> mitarbeiterQuery = from m in _context.Mitarbeiters
                                                   orderby m.Nachname
                                                   select m;*/
            var mitarbeiterList = await _context.Mitarbeiters.ToListAsync(); // Fetch list of employees



            var viewModel = new TicketCreateViewModel
            {
                Ticket = new Ticket(),
                Status = new SelectList(await statusQuery.Distinct().ToListAsync()),
                //Mitarbeiter = new SelectList(await mitarbeiterQuery.Distinct().ToListAsync())
                MitarbeiterList = mitarbeiterList
            };

            return View(viewModel);
        }

        // POST: Tickets/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TicketCreateViewModel ticketCreateViewModel)
        {
            var mitarbeiter = await _context.Mitarbeiters
            .FirstOrDefaultAsync(m => m.Id == ticketCreateViewModel.Ticket.MitarbeiterId);

            if (mitarbeiter != null)
            {
                ticketCreateViewModel.Ticket.Mitarbeiter = mitarbeiter; // Link the selected Mitarbeiter
            }

            _context.Add(ticketCreateViewModel.Ticket);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Details), new { id = ticketCreateViewModel.Ticket.Id});
        }

        // GET: Tickets/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {


            if (id == null)
            {
                return NotFound();
            }

            // get ticket by ID
            var ticket = await _context.Ticket
            .Include(t => t.Status)
            .Include(t => t.Mitarbeiter)

            .FirstOrDefaultAsync(t => t.Id == id);

            // get status list
            IQueryable<string> statusQuery = from t in _context.Ticket
                                             join s in _context.Status on t.StatusId equals s.Id
                                             orderby s.Name
                                             select s.Name;

            IQueryable<dynamic> mitarbeiterQuery = from t in _context.Ticket
                                                   join m in _context.Mitarbeiters on t.MitarbeiterId equals m.Id
                                                   orderby m.Vorname
                                                   select  m.Vorname + " " + m.Nachname;

            var viewModel = new TicketEditViewModel
            {
                Mitarbeiter = new SelectList(await mitarbeiterQuery.ToListAsync()),
                Ticket = ticket,
                Status = new SelectList(await statusQuery.Distinct().ToListAsync())
            };


            return View(viewModel);
        }


        // POST: Tickets/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, TicketEditViewModel ticketEditViewModel)
        {
            if (id != ticketEditViewModel.Ticket.Id)
            {
                return NotFound();
            }


            try
            {
                _context.Update(ticketEditViewModel.Ticket);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TicketExists(ticketEditViewModel.Ticket.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToAction(nameof(Index));

        }

        // GET: Tickets/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var ticket = await _context.Ticket
                .FirstOrDefaultAsync(t => t.Id == id);


            if (ticket == null)
            {
                return NotFound();
            }

            return View(ticket);
        }

        // POST: Tickets/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var ticket = await _context.Ticket.FindAsync(id);
            if (ticket != null)
            {
                _context.Ticket.Remove(ticket);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TicketExists(int id)
        {
            return _context.Ticket.Any(e => e.Id == id);
        }
    }
}
