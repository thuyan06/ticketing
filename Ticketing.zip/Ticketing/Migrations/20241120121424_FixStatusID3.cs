﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ticketing.Migrations
{
    /// <inheritdoc />
    public partial class FixStatusID3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_Status_StatusID",
                table: "Ticket");

            migrationBuilder.RenameColumn(
                name: "StatusID",
                table: "Ticket",
                newName: "StatusId");

            migrationBuilder.RenameIndex(
                name: "IX_Ticket_StatusID",
                table: "Ticket",
                newName: "IX_Ticket_StatusId");

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_Status_StatusId",
                table: "Ticket",
                column: "StatusId",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Ticket_Status_StatusId",
                table: "Ticket");

            migrationBuilder.RenameColumn(
                name: "StatusId",
                table: "Ticket",
                newName: "StatusID");

            migrationBuilder.RenameIndex(
                name: "IX_Ticket_StatusId",
                table: "Ticket",
                newName: "IX_Ticket_StatusID");

            migrationBuilder.AddForeignKey(
                name: "FK_Ticket_Status_StatusID",
                table: "Ticket",
                column: "StatusID",
                principalTable: "Status",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
