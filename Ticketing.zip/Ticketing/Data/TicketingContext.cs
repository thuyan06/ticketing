﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Ticketing.Models;

namespace Ticketing.Data
{
    public class TicketingContext : DbContext
    {
        public TicketingContext (DbContextOptions<TicketingContext> options)
            : base(options)
        {
        }

        public DbSet<Ticketing.Models.Ticket> Ticket { get; set; } = default!;
        public DbSet<Ticketing.Models.Status> Status { get; set; } = default!;
        public DbSet<Ticketing.Models.Mitarbeiter> Mitarbeiters { get; set; } = default!;


    }
}
