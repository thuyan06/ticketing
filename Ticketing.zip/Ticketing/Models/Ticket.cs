﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace Ticketing.Models
{
    public class Ticket
    {

        public int Id { get; set; }
        public string Betreff { get; set; }
        public string Beschreibung { get; set; }

        public int StatusId { get; set; }
        public Status Status { get; set; }

        public int MitarbeiterId { get; set; }
        public Mitarbeiter Mitarbeiter { get; set; }


    }



}
