﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace Ticketing.Models;

public class TicketStatusViewModel
{
    public List<Ticket>? Tickets { get; set; }
    public SelectList? Status { get; set; }
    public string? Name { get; set; }
    public string? SearchString { get; set; }

    public SelectList? Mitarbeiters { get; set;}
}