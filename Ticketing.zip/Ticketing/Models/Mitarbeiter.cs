﻿namespace Ticketing.Models
{
    public class Mitarbeiter
    {

        public int Id { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }

        public string Email { get; set; }

        public ICollection<Ticket> Tickets { get; set; }


    }
}
