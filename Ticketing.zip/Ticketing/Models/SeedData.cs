﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Ticketing.Data;
using System;
using System.Linq;
using Ticketing.Models;


namespace Ticketing.Models
{

    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new TicketingContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<TicketingContext>>()))

            {

                // Look for any tickets.
                if (!context.Mitarbeiters.Any())
                {
                    context.Mitarbeiters.AddRange(
                        new Mitarbeiter
                        {
                            Vorname = "Max",
                            Nachname = "Mustermann",
                            Email = "max.mustermann@pcetera.com"
                        },
                        new Mitarbeiter
                        {
                            Vorname = "Tom",
                            Nachname = "Meier",
                            Email = "meier.eier@gmail.com"
                        },
                        new Mitarbeiter
                        {
                            Vorname = "Lena",
                            Nachname = "Klein",
                            Email = "lena.klein@gmail.com"
                        },
                        new Mitarbeiter
                        {
                            Vorname = "Karl",
                            Nachname = "Wagner",
                            Email = "karl.wagner@gmail.com"
                        },
                        new Mitarbeiter
                        {
                            Vorname = "Olivia",
                            Nachname = "Zimmer",
                            Email = "olivia.zimmer@gmail.com"
                        }
                    );
                }

                // Look for any tickets.
                if (!context.Status.Any())
                {
                    context.Status.AddRange(
                        new Status
                        {
                            Name = "Offen"
                        },
                        new Status
                        {
                            Name = "Geschlossen"
                        },
                        new Status
                        {
                            Name = "Abgelehnt"
                        },
                        new Status
                        {
                            Name = "In Bearbeitung"
                        },
                        new Status
                        {
                            Name = "Wartet auf Rückmeldung"
                        }
                    );
                }

                // Look for any tickets.
                if (!context.Ticket.Any())
                {
                    context.Ticket.AddRange(
                        new Ticket
                        {
                            Betreff = "Probleme beim Systemstart",
                            Beschreibung = "Das System startet nicht korrekt und bleibt hängen.",
                            StatusId = 1,
                            MitarbeiterId = 1
                        },
                        new Ticket
                        {
                            Betreff = "Fehler bei der Datenbankabfrage",
                            Beschreibung = "Die SQL-Abfragen führen zu unerwarteten Ergebnissen.",
                            StatusId = 2,
                            MitarbeiterId =2
                        },

                        new Ticket
                        {
                            Betreff = "Serverausfall",
                            Beschreibung = "Der Server ist seit gestern nicht erreichbar.",
                            StatusId = 3,
                            MitarbeiterId = 3


                        },

                        new Ticket
                        {
                            Betreff = "Zahlungsprobleme",
                            Beschreibung = "Die Zahlung für den Auftrag wurde nicht verarbeitet.",
                            StatusId = 4,
                            MitarbeiterId = 4

                        },


                        new Ticket
                        {
                            Betreff = "Software-Update fehlerhaft",
                            Beschreibung = "Das Update hat die Anwendung instabil gemacht.",
                            StatusId=5,
                            MitarbeiterId = 5

                        }


                    );
                }                

                context.SaveChanges();
            }
        }
    }
}
