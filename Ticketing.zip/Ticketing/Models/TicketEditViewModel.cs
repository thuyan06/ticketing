﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace Ticketing.Models
{
    public class TicketEditViewModel
    {
        public Ticket Ticket { get; set; }
        public SelectList? Status { get; set; }
        public SelectList? Mitarbeiter { get; set; }
    }
}
