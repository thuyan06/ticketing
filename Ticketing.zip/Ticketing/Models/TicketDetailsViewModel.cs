﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace Ticketing.Models
{
    public class TicketDetailsViewModel
    {

        public Ticket Ticket { get; set; }

        public Status? Status { get; set; }


    }
}
